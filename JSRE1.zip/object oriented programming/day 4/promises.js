var today = "SUNDAY"

console.log("A random calculation happened ", 2 + 2)
let promise = new Promise(
     (resolve, reject) => {
        if(today === "SUNDAY"){
            resolve("Today is training day")
        }else{
            reject("Today is not a training day")
        }
    }
)

console.log("We just declared promise")
console.log("Now we will try to use promise")
promise
    .then(
        (result) => {console.log("It was successful with result: " + result)},
        (error) => {console.log("It failed with error: " + error)}
    )
console.log("Another random calculation happened ", 10 + 5)

let stepsToWalk = 100000;
let requiredMinimumStep = 100000
console.log("steps have been defined ")

console.log("We attempt to make a goForAWalk promise")
let goForAWalk = new Promise(
    (resolve, reject) => {
        for(let i= 0; i <= stepsToWalk; i++){
            new Date() // lets assume walking is happening here
        }
        if(stepsToWalk < requiredMinimumStep){
            reject("Not enough steps")
        }else {
            resolve("you completed the walk")
        }
    }
)
console.log("goForAWalk promise now decleared ")

console.log("We attempt to use goForAWalk promise")

goForAWalk.then(
    (result) => {
        console.log("Congrats, "+ result)
    },
    (error) => {
        console.log("We are sorry, "+ error)
    }
)
console.log("We successfully called to the promise")

let a = 4;
let b = 20;

console.log (a - b);
console.log("the program has ended?")

let someVar = 1;
let somePromise = new Promise(
    (resolve, reject) => {
        if(someVar === 1){
            resolve("SomeVar is 1")
        }
        if(someVar === 0){
            reject("SomeVar is 0")
        }
        throw new Error("Something bad happened")
    }
)

somePromise
    .finally(() => {console.log("Our promise completed sucessfully")})
    .then((result) => {console.log("then:"+result)})
    .catch(error => console.log("catch:"+error))
