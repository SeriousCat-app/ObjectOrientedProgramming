class Pet {
    constructor(name, weight, type) {
        let iAmPrivate = ""
        this.name = name;
        this.weight = weight;
        this.type = type;
    }
    introducePet(){
        return `
         Hello, my name is ${this.name}
         my weight is ${this.weight} kg
         i am a ${this.type}
        `;
    }
    setName(newName = ""){
        this.name = newName;
    }
}

// gets all the functionality of the parent Pet and able to add more functionality to it
class Cat extends Pet{
    constructor(name, weight, type, superPowers) {
        // ensures that this child receives all the fields on the parent Pet object
       super(name, weight, type);
       this.superPowers = superPowers
    }
    // only available to cats
    whatAreYourSuperPowers(){
        let response = 'My super powers are:\n';
        this.superPowers.forEach((currentSuperPower)=>{
            response += currentSuperPower +"\n"
        })
        return response;
    }
}
let fluffy = new Cat("fluffy", 2.5, "cat", ['running', 'jumping', 'swimming'])

console.log(fluffy.introducePet())
console.log(fluffy.whatAreYourSuperPowers())

class Dog extends Pet{
    constructor(name, weight, type, abilities) {
        // ensures that this child receives all the fields on the parent Pet object
        super(name, weight, type);
        this.abilities = abilities
    }
    whatAreYourAbilities(){
        let response = 'My abilities are:\n';
        this.abilities.forEach((currentAbility)=>{
            response += currentAbility +"\n"
        })
        return response;
    }
}

let barky = new Dog("barky", 6.5, "dog", ['barking', 'cuteness', 'eating'])

console.log(barky.introducePet())
console.log(barky.whatAreYourAbilities())


class Rat extends Pet{
    constructor(name, weight, type) {
        // ensures that this child receives all the fields on the parent Pet object
        super(name, weight, type);
    }

    introducePet(){
        return `
         Hello other pets, my name is ${this.name}
         my weight is ${this.weight} kg
         i am a ${this.type}
         i am special pet
        `;
    }
}

let raty = new Rat("raty", 6.5, "rat")

raty.setName("RatMan")
console.log(raty.introducePet())

class GermanShep extends Dog{
    constructor(name, weight, type, abilities, height) {
        // ensures that this child receives all the fields on the parent Pet object
        super(name, weight, type, abilities);
        this.height = height
    }
    introducePet(){
        return `
         Hello, my name is ${this.name}
         my weight is ${this.weight} kg
         my height is ${this.height} cm
         i am a special breed of ${this.type}
        `;
    }
}

let bingo = new GermanShep("bingo", 6.5, "dog", ['barking', 'cuteness', 'eating'], 15.5)

console.log(bingo.introducePet())
