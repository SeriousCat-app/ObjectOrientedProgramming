let addition = function (fNumber, sNumber){
    return fNumber + sNumber;
}
console.log(addition(2, 6))

let subtraction = (firstNumber, secondNumber) => {
    answer = firstNumber - secondNumber;
    return answer;
}
console.log(subtraction(25, 6))

let moreProfessionalSubtraction =
    (firstNumber, secondNumber) => firstNumber - secondNumber;

console.log(moreProfessionalSubtraction(25, 6))

const zinosData = {
    "name": "name",
    "phone": "phone",
    "message": "Hello stranger!"
}

let returnsZinosData = () => (zinosData);

console.log(returnsZinosData())

function someFunction(firstNumber = 0, secondNumber = 0) {

    console.log(firstNumber + secondNumber)
}

someFunction(1)

function validateData (name, phone, email = false, password = false){
    if(!email){
        throw new Error("Please provide email")
    }
    if(password === false){
        throw new Error("Please provide password")
    }
    try{
        if(name.length < 1){
            throw new Error("Please provide name")
        }
    }catch (error) {
        console.log(error)
    }

    console.log("Registration successful")
}

validateData("", "458687", "ZINOADIDI", "MYPASSWORD")
