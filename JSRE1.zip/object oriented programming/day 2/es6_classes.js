/* old way of making classes using functions */
let OldPet = function (name, weight, type) {
    this.id = 2334533;
    let _name = name;
    let _weight = weight;
    let _type = type;
    this.introducePet = function(){
        return `
         Hello, my name is ${_name}
         my weight is ${_weight} kg
         i am a ${_type}
        `;
    }
    this.getName = function (){
        return _name;
    }

    this.setName = function (newName = ""){
        _name = newName
    }
}

/*new way es6 declaring classes*/
class Pet {
    constructor(name, weight, type, superPowers = []) {
        let iAmPrivate = ""
        this.name = name;
        this.weight = weight;
        this.type = type;
        this.superPowers = superPowers;
    }
    introducePet(){
        return `
         Hello, my name is ${this.name}
         my weight is ${this.weight} kg
         i am a ${this.type}
        `;
    }
    setName(newName = ""){
        this.name = newName;
    }
}

let fluffy = new Pet("fluffy", "2.5", "cat")
let barky = new OldPet("barky", "2.5", "dog" )

// you can have regular objects and arrays in the classes as well
let slowly = new Pet("slowly", "1.5", "snail",[
        'walk slowly',
            'eat slowly'
    ])

slowly.setName("lucky")

console.log(fluffy.introducePet())
console.log(barky.introducePet())
console.log(slowly.superPowers[1])
slowly.superPowers.push('rolling')
console.log(slowly.superPowers)
