pets = [
    {id: 45, "name": "Dingo", "type": "dog"},
    {id: 24, "name": "fluffy", "type": "cat"},
    {id: 33, "name": "birdy", "type": "cat"},
    {id: 30, "name": "ratty", "type": "rat"},
    {id: 26, "name": "birdy", "type": "bird"},
    {id: 27, "name": "barky", "type": "dog"}
]

deletePetFromList = (petId) => {
    pets.map((pet, index) => {
        return pet.id !== petId
    })
}

id = 24;

newPetList = pets.map((pet, index) => {
    if(pet.id === id) return pet;
})

let petName = 'dingo';

pets.map((pet, index) => {
    if(pet.name.toLowerCase() === petName){
        pet.name = "My new name"
    }
    return pet;
})

console.table(newPetList)
console.table(pets)

newPetFilterList = pets.filter((pet, index) => {
    if(pet.id === id) return pet;
})

pets.filter((pet, index) => {
    if(pet.name.toLowerCase() === petName){
        pet.name = "My new name"
    }
    return pet;
})

console.table(newPetFilterList)
console.table(pets.filter((pet, index) => {
    if(pet.name.toLowerCase() === petName){
        pet.name = "My  new new name"
    }
    return pet;
}))

console.table(pets)

