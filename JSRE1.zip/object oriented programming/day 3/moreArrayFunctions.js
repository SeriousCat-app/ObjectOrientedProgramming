let pets = [
    'lizard',
    'dog',
    'rat',
    'spider',
    'cat',
    'croc'
]

console.log(pets.join())
console.log(pets.join("\ni have a "))

let allPetNamesTogether = pets.join()
console.log(allPetNamesTogether);

let newArrayOfPets = [...pets];
console.log(
    newArrayOfPets.shift(), newArrayOfPets
);
console.log(
    [...pets].pop()
);
console.log(pets.join());

let sortArrayAndAddNewPet = [...pets];
sortArrayAndAddNewPet.unshift('rabbit')
console.log(sortArrayAndAddNewPet)

let exampleUsingDelete = [...pets];

/*doesnt free up the memory space it deletes from, dont use it if you dont need to keep the memory space*/
console.log(exampleUsingDelete)
delete exampleUsingDelete[0];
console.log(exampleUsingDelete)
exampleUsingDelete[0] = "rabbit"
console.log(exampleUsingDelete)

let exampleUsingSplice = [...pets];
exampleUsingSplice.splice(2, 1)
console.log(exampleUsingSplice)


console.log(pets.toString())

let myBio = [
    'About Me: I am the guy you want to be. \n',
    'Contact: \n Phone: 34558585 \n Email: zino@zino.com. \n',
]
console.log(myBio.join("\n"))


