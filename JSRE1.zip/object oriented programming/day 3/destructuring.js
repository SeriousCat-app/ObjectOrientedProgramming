product = {
    name: "rice",
    weight: "2kg",
    noAvailable: 5
}
let cake = {...product};
cake.name = "cake";

let milk = {...product};
milk.name = "milk";

let user = {
    name: "zino",
    id: 29943,
    password: "zinoadidi",
    email: "zinoadidi@gmail.com"
}

/*more faster way but name needs to match*/
let {password, email, phoneNo} = user;
// changes to original object not reflecting in new variables
user.password = "newPassword";
// possibility to change newly created variable value
email = "myNewEmail@zino.com"
console.log("Password: "+password)
console.log("email: "+email)
console.log("phoneNo: "+phoneNo)
/*
regular way can be slower if you have many items to extract
let password = user.password
let email = user.email
*/
