let pets = [
    {id: 45, "name": "Dingo", "type": "dog"},
    {id: 24, "name": "fluffy", "type": "cat"},
    {id: 33, "name": "birdy", "type": "cat"},
    {id: 30, "name": "ratty", "type": "rat"},
    {id: 26, "name": "birdy", "type": "bird"},
    {id: 27, "name": "barky", "type": "dog"}
]
// we have a simple list
let simplePetList = [
    10,
    45,
    3,
    56,
    344,
    1
]
sortSimpleList = () => {
    simplePetList.sort()
    displaySimpleList()
}

sortPetsById = (sortType) => {
    pets.sort(
        (previousPet, currentPet) => {
            if(previousPet.id < currentPet.id) return -1;
            if(previousPet.id > currentPet.id) return 1;
        }
    )

    if (sortType === 'DESC'){
        pets.reverse();
    }
    displayPets()
}

sortPetsByName = (sortType) => {
    pets.sort(
        (previousPet, currentPet) => {
            if(previousPet.name < currentPet.name) return -1;
            if(previousPet.name > currentPet.name) return 1;
            return 0;
        }
    )
    if (sortType === 'DESC'){
        pets.reverse();
    }
    displayPets()
}

sortPetsByAnyField = (fieldName, sortType) => {
    pets.sort(
        (previousPet, currentPet) => {
            if(previousPet[fieldName] < currentPet[fieldName]) return -1;
            if(previousPet[fieldName] > currentPet[fieldName]) return 1;
            return 0;
        }
    )
    if (sortType === 'DESC'){
        pets.reverse();
    }
    displayPets()
}

function displaySimpleList() {
    console.log(simplePetList)
    let simpleListHtml = document.querySelector("#simpleList");
    // clear existing data in html
    simpleListHtml.innerHTML = "";
    simplePetList.forEach((pet) =>{
        simpleListHtml.innerHTML += `<li>${pet}</li>`
    })
}

function displayPets() {
    console.log(pets)
    let displayArea = document.querySelector("#displayArea");
    // clear existing data in html
    displayArea.innerHTML = "";
    pets.forEach((pet) =>{
        displayArea.innerHTML += `
            <tr>
                <td>${pet.id}</td>
                <td>${pet.name}</td>
                <td>${pet.type}</td>
            </tr>
        `;
    })
}

let fluffy = {id: 33, "name": "fluffy", "type": "cat"}

console.log(fluffy.name)
console.log(fluffy['name'])
