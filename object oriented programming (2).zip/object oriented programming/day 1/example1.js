/*older way of implementing classes*/
function Person(name, age, password){
    this.name = name;
    this.age = age;
    var password = password;
    var securityKey = "something";

    this.getSecurityKey = function(){
        return securityKey;
    }
    this.setSecurityKey = function(key){
        securityKey = key;
    }
    this.getBio = function(){
        return "Hello, I am " + name
            + ", i am " + age + " years old"
            + ", Its nice to meet you!"
    }
}

function ourFunctionWithoutData(){
    this.sampleVariable = "sample"

    if(this.sampleVariable != "john"){
        //throw new Error("I failed")
    }

    return "i succeeded"

}

let ourFunctionWithoutData1 = new ourFunctionWithoutData();

let james = new Person("james", 22, "myPassword")
let peter = new Person("peter", 106, "myOwnPassword")

console.log(peter.getBio())
console.log(james.getBio())

console.log(james instanceof Person)
console.log(Person instanceof Object)


let person1 = new Person("jude", 34, "hisPassword")
// this doesnt work because security key is not available outside
// person1.securityKey = "zino"
// person1.securityKey
person1.getSecurityKey()
person1.getSecurityKey()
person1.setSecurityKey("i am a new key")
person1.getSecurityKey()

/*Object*/
let product = {
    name: "rice",
    weight: "2kg",
    noAvailable: 5,
    reduceNoAvailable: function (noItemSold = 0) {
        this.noAvailable -= noItemSold;
    },
    checkExpiryDate: function () {
        return this.expiryDate;
    }
}
let newProduct = Object.create(product);
newProduct.name = "something";
newProduct.expiryDate = new Date().toISOString();

console.log(newProduct.checkExpiryDate())
newProduct.reduceNoAvailable(1)
console.log(newProduct.noAvailable)

product.name = "John"
product.reduceNoAvailable()

/// this doesnt work because product is not a class
// new product("john")
