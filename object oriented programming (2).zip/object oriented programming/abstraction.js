
let GenericBankApplication = {
    number: 0,
    getCurrentValue: function(calculationToPerform){
        if(calculationToPerform === "Addition"){
            return this.calculateAdition(this.number)
        }else if (calculationToPerform === "Subtraction"){
            return this.calculateSubtraction(this.number)
        }
    },
    /*this will be */
    calculateInterestRate(personalRate, period) {
        return personalRate * period;
    },
    calculateSubtraction(number) {
        return number;
    }

}

let youthBankApplication = Object.create(GenericBankApplication);

youthBankApplication.calculateInterestRate = function(personalRate, period){
    return personalRate - 10 * period;
}

let adultBankApplication = Object.create(GenericBankApplication);

adultBankApplication.calculateInterestRate = function(personalRate, discount, period){
    return personalRate - 20 * period * discount;
}

adultBankApplication.calculateInterestRate = function(personalRate, period){
    return personalRate - 20 * period * period;
}

console.log(youthBankApplication.calculateInterestRate(100, 20))
console.log(adultBankApplication.calculateInterestRate(200, 15))
