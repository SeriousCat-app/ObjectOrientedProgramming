
let Pet = function (name, weight, type) {
    this.id = 2334533;
    let _name = name;
    let _weight = weight;
    let _type = type;
    this.introducePet = function(){
        return `
         Hello, my name is ${_name}
         my weight is ${_weight} kg
         i am a ${_type}
        `;
    }
    this.action = function (walk) {

    }
    this.action = function (run) {

    }
    this.getName = function (){
        return _name;
    }

    this.setName = function (newName = ""){
        _name = newName
    }
}

let fluffy = new Pet("fluffy", 2.5, "cat")

let johny = new Pet("johny", 2.5, "cat")
let barky = new Pet("barky", 2.5, "cat")

console.log(fluffy.introducePet())
console.log(fluffy.getName())
/*Unable to access name directly because its private*/
console.log(fluffy._name)
/*able to access ID*/
console.log(fluffy.id)


function submitPet(){
    let petName = document.querySelector('#petName');
    let petType = document.querySelector('#petType');
    let petWeight = document.querySelector('#petWeight');

    let ourPet = new Pet(petName.value, petWeight.value, petType.value)

    displayPet(ourPet)
}

function displayPet(pet) {
    document.querySelector('#displayArea').innerHTML =
    pet.introducePet();
}
