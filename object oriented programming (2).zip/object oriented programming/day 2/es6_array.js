let pets = [
    {"name": "bingo", "type": "dog"},
    {"name": "fluffy", "type": "cat"},
    {"name": "ratty", "type": "rat"},
    {"name": "birdy", "type": "bird"},
    {"name": "barky", "type": "dog"}
]

let petToFind = "fluffy";

function findPetByName(currentPet, index, array){
    if(currentPet.name === petToFind){
        return true
    }
}
let petFound = pets.find(findPetByName)

console.log(petFound)
console.table(pets)

const showAllPets = () => {
    let petsDiv = document.querySelector('#allusersdiv');
    petsDiv.innerHTML = `
        <table>
        <thead>
        <tr><td>NAME</td><td>TYPE</td></tr>
        </thead>
    `;
    pets.forEach((pet) => {
        petsDiv.innerHTML += `
                <tr>
                    <td>${pet.name}</td>
                    <td>${pet.type}</td>
                </tr>
        `;
    });
    petsDiv.innerHTML += "</table>";
}
