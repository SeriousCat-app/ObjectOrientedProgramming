const users = []

const register = () => {

    const username = document.querySelector('#register_username').value
    const name = document.querySelector('#register_name').value
    const password = btoa(document.querySelector('#register_password').value)

    users.push({
        'id': btoa(username+name),
        'name':name,
        'username':username,
        'password': password
    })

    alert("Registration successful")
}

const login = () => {
    const username = document.querySelector('#login_username').value
    const password = btoa(
        document.querySelector('#login_password').value
    )

    const existingUser = users.find(
        (currentUser) =>
        currentUser.username === username &&
            currentUser.password === password
    )

    if(existingUser !== undefined){
        displayProfile(existingUser)
    }else {
        alert("User does not exist or password incorrect")
    }

}

const displayProfile = (user) => {
    document.querySelector('#displayArea')
        .innerHTML = `
            <table>  
                <tr><td>ID</td><td>${user.id}</td></tr>
                <tr><td>NAME</td><td>${user.name}</td></tr>
                <tr><td>USERNAME</td><td>${user.username}</td></tr>
            </table>
        `;
}

const showAllUsers = () => {
    let usersDiv = document.querySelector('#allusersdiv');
    usersDiv.innerHTML = `
        <table>
        <thead>
        <tr> <td>ID</td><td>NAME</td><td>USERNAME</td></tr>
        </thead>
    `;
    users.forEach((user) => {
        usersDiv.innerHTML += `
                <tr>
                    <td>${user.id}</td>
                    <td>${user.name}</td>
                    <td>${user.username}</td>
                </tr>
        `;
    });
    usersDiv.innerHTML += "</table>";
}
