// Cannot access a below because its local scope
// console.log(a)
{
    // local scope variable
    let a = 20;
}

let functionCannotAccessVariableAbove = function () {
    console.log(a)
}


var pet = function () {
    console.log("i am a pet")
}

pet();

pet = "something else"

// this will not work anymore because value has changed above
// pet()

const masterPet = function () {
    console.log("i am a master pet")
}

masterPet();

try {
    masterPet = "something else"
    // some more code
}catch (error) {
    console.log("===============")
    console.log(error)
    console.log("===============")
}

masterPet()

const thisIsOurArray = [
    'value1',
    'value2',
    'value3'
]

console.log(thisIsOurArray)
// content inside array you can change. Data type you cannot change
thisIsOurArray[1] = "custom value"
console.log(thisIsOurArray)

