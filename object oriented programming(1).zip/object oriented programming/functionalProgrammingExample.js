
let james = {
    name: '',
    age: '',
    password: '',
    secretkey: ''
}

james.name = "james"
james.age = 25
james.password = "myPassword"
james.secretkey = "secret"

console.log(james.secretkey)


let peter = {
    name: '',
    age: '',
    password: '',
    secretkey: ''
}

peter.name = "peter"
peter.age = 35
peter.password = "myPasswordpeter"
peter.secretkey = "secretpeter"

console.log(peter.secretkey)
