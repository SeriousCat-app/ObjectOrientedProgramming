let Pet = function (name, weight, type) {
    this.id = 2334533;
    let _name = name;
    let _weight = weight;
    let _type = type;

    this.introducePet = function(){
        return `
         Hello, my name is ${_name}
         my weight is ${_weight} kg
         i am a ${_type}
        `;
    }

    this.getName = function (){
        return _name;
    }

    this.setName = function (newName = ""){
        _name = newName
    }
}

let houseCat = new Pet("fluffy", 2.5, "cat")

houseCat.prototype.introducePet = function(){
        return `
         i am a house ${_type}
        `;
}

console.log(houseCat.introducePet())
